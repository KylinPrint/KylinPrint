<div align="center">
    <img src="http://www.dcatadmin.com/assets/img/logo-text.png" height="80"> 
</div>
<br>


## Dcat Admin 操作日志扩展

### 安装

下载`zip`压缩包，打开扩展管理页面，点击`本地安装`按钮选择提交，然后找到`form-step`行点击`启用`按钮。

