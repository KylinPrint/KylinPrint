<?php

return [
    '1.0.0' => [
        'Initialize extension.',
        'create_opration_log_table.php',
    ],
];
