<?php

return [
    'title' => 'Operation Log',
    'setting_title' => 'Operation Log',
];
