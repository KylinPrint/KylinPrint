<?php

return [
    'title' => '操作日志',
    'setting_title' => '操作日志',
];
